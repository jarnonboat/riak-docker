-module(ex1).
-export([add/2]).

add(X,Y) ->
    X + Y.

int() ->
    int.
